#!/bin/bash
#sudo avahi-set-host-name studyos
#sudo avahi-daemon
sudo python3 /home/studyos/studyOS/mit-flask/rec.py
