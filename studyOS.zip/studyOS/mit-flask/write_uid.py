import json

lists = {
"a3:35:ad:91":"Dima van der Meer", 
"14:6b:65:a4":"Milan Poppe", 
"84:cc:5e:a4":"ILAY",
"23:6d:25:95":"Jeremy Wilsdorf"
}

with open("uid_resolve.json", "w") as filo:
    json.dump(lists, filo)
