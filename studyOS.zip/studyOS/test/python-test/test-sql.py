from datetime import datetime
import mysql.connector

mydb = mysql.connector.connect(
    host="127.0.0.1",
    user="studyos",
    passwd="123123",
    database="techtarget"
)

mycursor = mydb.cursor()

sql = "INSERT INTO studys (UID, Name, Time) VALUES (%s,%s,%s)"
val = ("A4 DF 88 H7", "Gebert", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

mycursor.execute(sql, val)

mydb.commit()
print(mycursor.rowcount, "record inserted.")
print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
