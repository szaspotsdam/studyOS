list = {
" A3 35 AD 91":"Dima Wattenmeer", 
" 14 6B 65 A4":"AIDA Ilay van der Meer", 
" 84 CC 5E A4":"AIDA Dima van der Meer",
" 23 6D 25 95":"Jeremy Doofknödel"}

while True:
   i = input()
   if i == "":
      continue
      
   try:
      print(list[i])
   except KeyError:
      print(i, "nicht im System.")
