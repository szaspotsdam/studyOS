import mysql.connector

mydb = mysql.connector.connect(
   host="127.0.0.1",
   user="studyos",
   passwd="123123",
   database="techtarget"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM studys")


myresult = mycursor.fetchall()

for x in myresult:
  print(x) 
