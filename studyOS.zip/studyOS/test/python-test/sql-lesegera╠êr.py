from datetime import datetime
import mysql.connector

list = {
" A3 35 AD 91":"Dima Wattenmeer", 
" 14 6B 65 A4":"AIDA Ilay van der Meer", 
" 84 CC 5E A4":"AIDA Dima van der Meer",
" 23 6D 25 95":"Jeremy Doofknödel"}

def sql_conection(uid, name):
   name = name
   mydb = mysql.connector.connect(
      host="localhost",
      user="studyos",
      passwd="Dimi123123",
      database="techtarget"
   )

   mycursor = mydb.cursor()
   
   sql = "INSERT INTO studys (UID, Name, Time) VALUES (%s,%s,%s)"
   val = (uid, name, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
   mycursor.execute(sql, val)

   mydb.commit()
   print(mycursor.rowcount, "record inserted.")
   print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
   print(name)
   print("*****"*5)


while True:
   i = input()
   if i == "":
      continue
      
   try:
      print(list[i])
      sql_conection(i, list[i])
   except KeyError:
      print(i, "nicht im System.")

