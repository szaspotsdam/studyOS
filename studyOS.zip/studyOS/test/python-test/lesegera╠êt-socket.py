import socket

def client(data):
   # Client erstellen
   server_address = ('10.42.0.106', 12345)  # IP_des_Servers mit der IP-Adresse oder dem Hostnamen des Servers ersetzen 192.168.178.103
   client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   client.connect(server_address)

   try:
      # Daten senden
      #message = 'Hello, server!'
      client.sendall(data.encode())
      print('Daten gesendet:', data)

   finally:
      # Verbindung schließen
      client.close()


while True:
   i = input()
   if i == "":
      continue
      
   try:
      print(list[i])
      client(i)
   except KeyError:
      print(i, "nicht im System.")
   except ConnectionRefusedError:
      print("Cancel Connection!")
      exit(1)
