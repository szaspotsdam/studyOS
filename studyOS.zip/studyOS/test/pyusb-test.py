import usb.core
import usb.util
dev = usb.core.find(idVendor=0x0a5c, idProduct=0x5800)

# was it found?
if dev is None:
	print('Error, device not found')
	sys.exit(1)

# Host to device + vendor request
bmRequestSend = 0x40
# Device to host + vendor request
bmRequestRecv = 0xC0

# Write a control request, bmRequest = 1, wValue = 2, wIndex = 3, no extra data bytes
dev.ctrl_transfer(bmRequestSend, 1, 2, 3, 0)

#control request to read one byte from the USB device, bmRequest = 3, wValue = 2, wIndex = 1
data = dev.ctrl_transfer(bmRequestRecv, 3, 2, 1, 1)
print(data)

