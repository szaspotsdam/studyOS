from flask import Flask, request, Response
from functools import wraps

app = Flask(__name__)

# Benutzername und Passwort für die Authentifizierung
USERNAME = 'benutzer'
PASSWORD = 'passwort'

# Funktion zur Überprüfung der Anmeldeinformationen
def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

# Funktion zur Anzeige des Authentifizierungsfensters
def authenticate():
    return Response(
        'Bitte geben Sie Benutzername und Passwort ein.', 
        401,
        {'WWW-Authenticate': 'Basic realm="Login Required"'}
    )

# Dekorator für die Authentifizierung
def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

# Beispielroute, die Authentifizierung erfordert
@app.route('/')
@requires_auth
def index():
    return 'Erfolgreich authentifiziert!'

if __name__ == '__main__':
    app.run(debug=True)
