from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = '12341234'  # Setzen Sie eine geheime Schlüssel für die Sitzungsverwaltung

# Dummy-Benutzerdaten für Demonstration
users = {
    "dimi": "dima",
    "user2": "password2"
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Überprüfen, ob der Benutzer existiert und das Passwort korrekt ist
        if username in users and users[username] == password:
            # Benutzer erfolgreich authentifiziert, speichern Sie den Benutzernamen in der Sitzung
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            # Benutzer nicht authentifiziert, zeigen Sie eine Alert-Box an
            return render_template('login.html', alert=True)

    return render_template('login.html', alert=False)

@app.route('/dashboard')
def dashboard():
    # Überprüfen, ob der Benutzer angemeldet ist
    if 'username' in session:
        username = session['username']
        return render_template('dashboard.html', username=username)
    else:
        # Benutzer nicht angemeldet, umleiten zur Anmeldeseite
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    # Sitzung löschen, um Benutzer abzumelden
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)
